/* =========================================================
   PLAYLAND — app.js
   Runs on every page: toast utility + header interactions.
   ========================================================= */

function plToast(message, kind) {
  let region = document.getElementById('toast-region');
  if (!region) {
    region = document.createElement('div');
    region.id = 'toast-region';
    document.body.appendChild(region);
  }
  const el = document.createElement('div');
  el.className = 'toast' + (kind ? ' ' + kind : '');
  el.textContent = message;
  region.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, 3200);
}

document.addEventListener('DOMContentLoaded', () => {

  /* ---- mobile nav toggle ---- */
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      mainNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', mainNav.classList.contains('open'));
    });
  }

  /* ---- avatar / session state ---- */
  const avatarBtn = document.getElementById('avatarBtn');
  const dropdown = document.getElementById('userDropdown');
  const session = PL.getSession();

  if (avatarBtn) {
    if (session) {
      avatarBtn.innerHTML = session.username.trim().charAt(0).toUpperCase();
      avatarBtn.setAttribute('aria-label', 'Conta de ' + session.username);
    } else {
      avatarBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-6 8-6s8 2 8 6"/></svg>`;
      avatarBtn.setAttribute('aria-label', 'Entrar na conta');
    }

    avatarBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!session) {
        window.location.href = 'login.html';
        return;
      }
      if (dropdown) dropdown.classList.toggle('open');
    });
  }

  if (dropdown) {
    const whoEl = dropdown.querySelector('.who');
    if (session && whoEl) whoEl.textContent = 'Olá, ' + session.username;
    const logoutBtn = dropdown.querySelector('[data-logout]');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        PL.logout();
        plToast('Você saiu da sua conta.');
        setTimeout(() => window.location.href = 'index.html', 700);
      });
    }
    document.addEventListener('click', (e) => {
      if (!dropdown.contains(e.target) && e.target !== avatarBtn) {
        dropdown.classList.remove('open');
      }
    });
  }

  /* ---- header search: redirect to home with query ---- */
  const searchForm = document.getElementById('siteSearchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const q = searchForm.querySelector('input').value.trim();
      if (document.body.dataset.page === 'home') {
        document.dispatchEvent(new CustomEvent('pl:search', { detail: q }));
      } else {
        window.location.href = 'index.html?q=' + encodeURIComponent(q);
      }
    });
  }
});
