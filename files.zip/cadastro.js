/* =========================================================
   PLAYLAND — cadastro.js
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('cadastroForm');
  const userField = document.getElementById('cadUser');
  const emailField = document.getElementById('cadEmail');
  const passField = document.getElementById('cadPass');
  const confirmField = document.getElementById('cadConfirm');

  function setInvalid(field, message) {
    const wrap = field.closest('.field');
    wrap.classList.add('invalid');
    wrap.querySelector('.field-error').textContent = message;
  }
  function clearInvalid(field) { field.closest('.field').classList.remove('invalid'); }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let ok = true;
    [userField, emailField, passField, confirmField].forEach(clearInvalid);

    if (userField.value.trim().length < 3) { setInvalid(userField, 'Use pelo menos 3 caracteres.'); ok = false; }
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value.trim());
    if (!emailOk) { setInvalid(emailField, 'Informe um email válido.'); ok = false; }
    if (passField.value.length < 6) { setInvalid(passField, 'A senha precisa ter 6+ caracteres.'); ok = false; }
    if (confirmField.value !== passField.value || !confirmField.value) { setInvalid(confirmField, 'As senhas não coincidem.'); ok = false; }
    if (!ok) return;

    const result = PL.registerUser({ username: userField.value, email: emailField.value, senha: passField.value });
    if (!result.ok) {
      setInvalid(emailField, 'Já existe uma conta com esse usuário ou email.');
      plToast('Não foi possível criar a conta.', 'warn');
      return;
    }
    PL.setSession(result.user.username);
    plToast('Conta criada! Bem-vindo(a), ' + result.user.username + '.', 'good');
    setTimeout(() => window.location.href = 'index.html', 800);
  });

  document.getElementById('toggleCadPass').addEventListener('click', () => {
    passField.type = passField.type === 'password' ? 'text' : 'password';
  });

  document.querySelectorAll('[data-social]').forEach(btn => {
    btn.addEventListener('click', () => {
      plToast('Cadastro social indisponível nesta versão de demonstração.');
    });
  });
});
