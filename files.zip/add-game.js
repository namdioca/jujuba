/* =========================================================
   PLAYLAND — add-game.js
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  const session = PL.getSession();
  if (!session) {
    plToast('Entre na sua conta para adicionar um jogo.', 'warn');
    setTimeout(() => window.location.href = 'login.html?next=adicionar-jogo.html', 900);
    return;
  }

  let selectedCategoryId = null;
  let thumbDataUrl = null;
  let gameFileName = null;

  const chipList = document.getElementById('chipList');
  const thumbDrop = document.getElementById('thumbDrop');
  const thumbInput = document.getElementById('thumbInput');
  const newCatInput = document.getElementById('newCatInput');
  const newCatBtn = document.getElementById('newCatBtn');
  const gameFileInput = document.getElementById('gameFileInput');
  const gameFileLabel = document.getElementById('gameFileLabel');
  const form = document.getElementById('addGameForm');

  function renderChips() {
    const cats = PL.getCategories();
    chipList.innerHTML = cats.map(c => `
      <button type="button" class="chip-option ${c.id === selectedCategoryId ? 'selected' : ''}"
        style="background:${c.color}" data-cat="${c.id}">${c.emoji || ''} ${c.name}</button>
    `).join('');
  }
  renderChips();

  chipList.addEventListener('click', (e) => {
    const chip = e.target.closest('[data-cat]');
    if (!chip) return;
    selectedCategoryId = chip.dataset.cat;
    document.getElementById('categoryField').classList.remove('invalid');
    renderChips();
  });

  newCatBtn.addEventListener('click', () => {
    const name = newCatInput.value.trim();
    if (!name) {
      plToast('Digite um nome para a nova categoria.', 'warn');
      return;
    }
    const result = PL.addCategory(name);
    if (!result.ok) {
      plToast('Já existe uma categoria com esse nome. Escolha outro.', 'warn');
      return;
    }
    selectedCategoryId = result.category.id;
    newCatInput.value = '';
    renderChips();
    document.getElementById('categoryField').classList.remove('invalid');
    plToast('Categoria "' + result.category.name + '" criada!', 'good');
  });
  newCatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); newCatBtn.click(); }
  });

  thumbDrop.addEventListener('click', () => thumbInput.click());
  thumbInput.addEventListener('change', () => {
    const file = thumbInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      thumbDataUrl = reader.result;
      thumbDrop.classList.add('has-image');
      thumbDrop.classList.remove('invalid');
      thumbDrop.innerHTML = `<img src="${thumbDataUrl}" alt="Prévia do jogo">`;
    };
    reader.readAsDataURL(file);
  });

  gameFileInput.addEventListener('change', () => {
    const file = gameFileInput.files[0];
    gameFileName = file ? file.name : null;
    gameFileLabel.innerHTML = file
      ? `Arquivo selecionado: <strong>${file.name}</strong>`
      : `Nenhum arquivo selecionado ainda.`;
    if (file) document.getElementById('uploadRow').classList.remove('invalid');
  });

  function setInvalid(el, msg) {
    el.classList.add('invalid');
    const errEl = el.querySelector('.field-error');
    if (errEl) errEl.textContent = msg;
  }
  function clearInvalid(el) { el.classList.remove('invalid'); }

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const nomeField = document.getElementById('nomeField');
    const descField = document.getElementById('descField');
    const idadeField = document.getElementById('idadeField');
    const categoryField = document.getElementById('categoryField');
    const uploadRow = document.getElementById('uploadRow');

    [nomeField, descField, idadeField, categoryField, uploadRow].forEach(clearInvalid);
    thumbDrop.classList.remove('invalid');

    let ok = true;
    const nome = document.getElementById('nomeInput').value.trim();
    const descricao = document.getElementById('descInput').value.trim();
    const faixaEtaria = document.getElementById('idadeInput').value;
    const desenvolvedor = document.getElementById('devInput').value.trim();

    if (!nome) { setInvalid(nomeField, 'Dê um nome ao seu jogo.'); ok = false; }
    if (!descricao) { setInvalid(descField, 'Descreva brevemente o jogo.'); ok = false; }
    if (!faixaEtaria) { setInvalid(idadeField, 'Selecione a faixa etária.'); ok = false; }
    if (!selectedCategoryId) { setInvalid(categoryField, 'Escolha ou crie uma categoria.'); ok = false; }
    if (!gameFileName) { setInvalid(uploadRow, 'O arquivo do jogo é obrigatório para lançar o jogo.'); ok = false; }
    if (!thumbDataUrl) { thumbDrop.classList.add('invalid'); ok = false; }

    if (!ok) {
      plToast('Preencha os campos obrigatórios destacados.', 'warn');
      return;
    }

    const saved = PL.addGame({
      nome, descricao, faixaEtaria, desenvolvedor,
      categoria: selectedCategoryId,
      thumb: thumbDataUrl,
      arquivo: gameFileName,
      autor: session.username,
    });

    plToast('"' + saved.nome + '" foi publicado com sucesso! 🎮', 'good');
    setTimeout(() => window.location.href = 'index.html#cat-' + selectedCategoryId, 900);
  });
});
