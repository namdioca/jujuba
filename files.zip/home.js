/* =========================================================
   PLAYLAND — home.js
   Builds the homepage from data.js: carousel, category
   sections, search filtering, and the details modal.
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  const categories = PL.getCategories();
  const allGames = PL.getGames();

  /* ---------------- helpers ---------------- */

  function gameCardHTML(game, cat) {
    const bg = cat ? cat.color : '#999';
    return `
      <button class="game-card" data-id="${game.id}">
        <div class="card-art" style="background:${bg}22; color:${bg}">
          <span class="fold"></span>
          ${game.thumb ? `<img src="${game.thumb}" alt="">` : game.emoji || '🎮'}
        </div>
        <div class="card-title">${game.nome}</div>
        <div class="card-sub"><span>${cat ? cat.name.replace('Jogos de ', '').replace('Jogos da ', '') : ''}</span><span>${game.faixaEtaria || ''}</span></div>
      </button>`;
  }

  function renderSections(games) {
    const wrap = document.getElementById('categorySections');
    wrap.innerHTML = '';
    categories.forEach(cat => {
      const list = games.filter(g => g.categoria === cat.id);
      const section = document.createElement('section');
      section.className = 'category-section';
      section.id = 'cat-' + cat.id;
      section.innerHTML = `
        <div class="section-head">
          <span class="cat-chip" style="background:${cat.color}">${cat.emoji || ''} ${cat.name}</span>
          <span class="section-count">${list.length} jogo${list.length === 1 ? '' : 's'}</span>
        </div>
        ${list.length
          ? `<div class="card-grid">${list.map(g => gameCardHTML(g, cat)).join('')}</div>`
          : `<div class="empty-note">Ainda não há jogos nesta categoria. Que tal <a href="adicionar-jogo.html" style="color:${cat.color};text-decoration:underline;">adicionar o primeiro</a>?</div>`}
      `;
      wrap.appendChild(section);
    });
  }

  function renderSearchResults(games, query) {
    const wrap = document.getElementById('categorySections');
    const term = query.trim().toLowerCase();
    const results = games.filter(g => g.nome.toLowerCase().includes(term));
    wrap.innerHTML = `
      <section class="category-section">
        <div class="section-head">
          <span class="cat-chip" style="background:var(--blue)">🔎 Resultados para "${query}"</span>
          <span class="section-count">${results.length} encontrado${results.length === 1 ? '' : 's'}</span>
        </div>
        ${results.length
          ? `<div class="card-grid">${results.map(g => gameCardHTML(g, PL.categoryById(g.categoria))).join('')}</div>`
          : `<div class="empty-note">Nenhum jogo encontrado com esse nome. Tente outra palavra-chave.</div>`}
      </section>`;
  }

  /* ---------------- carousel ---------------- */

  function initCarousel(games) {
    const featured = games.filter(g => g.destaque);
    const slidesData = featured.length ? featured : games.slice(0, 4);
    const track = document.getElementById('carouselTrack');
    const dotsWrap = document.getElementById('carouselDots');
    track.innerHTML = slidesData.map(g => {
      const cat = PL.categoryById(g.categoria);
      return `
        <div class="slide">
          <div class="slide-art" style="background:${cat ? cat.color + '22' : '#eee'}; color:${cat ? cat.color : '#333'}">
            ${g.thumb ? `<img src="${g.thumb}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:16px">` : (g.emoji || '🎮')}
          </div>
          <div class="slide-body">
            ${cat ? `<span class="cat-chip" style="background:${cat.color}">${cat.name}</span>` : ''}
            <h3>${g.nome}</h3>
            <p>${g.descricao || ''}</p>
            <div class="slide-meta">
              <span class="meta-tag">Idade: ${g.faixaEtaria || 'Livre'}</span>
              <span class="meta-tag">${g.desenvolvedor || 'Independente'}</span>
            </div>
            <button class="btn btn-blue" data-play="${g.id}">▶ Jogar agora</button>
          </div>
        </div>`;
    }).join('');

    dotsWrap.innerHTML = slidesData.map((_, i) => `<button aria-label="Slide ${i + 1}" data-dot="${i}"></button>`).join('');

    let index = 0;
    let timer = null;
    const dots = () => Array.from(dotsWrap.children);

    function go(i) {
      index = (i + slidesData.length) % slidesData.length;
      track.style.transform = `translateX(-${index * 100}%)`;
      dots().forEach((d, di) => d.classList.toggle('active', di === index));
    }
    function next() { go(index + 1); }
    function prev() { go(index - 1); }
    function play() {
      stop();
      timer = setInterval(next, 5000);
    }
    function stop() { if (timer) clearInterval(timer); }

    document.getElementById('carPrev').addEventListener('click', () => { prev(); play(); });
    document.getElementById('carNext').addEventListener('click', () => { next(); play(); });
    dots().forEach((d, i) => d.addEventListener('click', () => { go(i); play(); }));
    const heroCard = document.querySelector('.hero-card');
    heroCard.addEventListener('mouseenter', stop);
    heroCard.addEventListener('mouseleave', play);

    go(0);
    if (slidesData.length > 1) play();

    track.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-play]');
      if (btn) openModal(btn.dataset.play);
    });
  }

  /* ---------------- modal ---------------- */

  const overlay = document.getElementById('gameModal');

  function openModal(id) {
    const games = PL.getGames();
    const game = games.find(g => g.id === id);
    if (!game) return;
    const cat = PL.categoryById(game.categoria);
    overlay.querySelector('.modal-art').style.background = cat ? cat.color + '22' : '#eee';
    overlay.querySelector('.modal-art').style.color = cat ? cat.color : '#333';
    overlay.querySelector('.modal-art').innerHTML = game.thumb ? `<img src="${game.thumb}" alt="">` : (game.emoji || '🎮');
    overlay.querySelector('h3').textContent = game.nome;
    overlay.querySelector('p').textContent = game.descricao || 'Sem descrição.';
    overlay.querySelector('[data-cat]').textContent = cat ? cat.name : '';
    overlay.querySelector('[data-cat]').style.background = cat ? cat.color : '#999';
    overlay.querySelector('[data-idade]').textContent = 'Idade: ' + (game.faixaEtaria || 'Livre');
    overlay.querySelector('[data-dev]').textContent = game.desenvolvedor || 'Independente';
    overlay.classList.add('open');
  }
  function closeModal() { overlay.classList.remove('open'); }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay || e.target.closest('.modal-close')) closeModal();
  });
  overlay.querySelector('[data-jogar]').addEventListener('click', () => {
    plToast('Em breve! Este é um catálogo de demonstração. 🎮');
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  document.getElementById('categorySections').addEventListener('click', (e) => {
    const card = e.target.closest('.game-card');
    if (card) openModal(card.dataset.id);
  });

  /* ---------------- search wiring ---------------- */

  function applyQuery(q) {
    const gamesNow = PL.getGames();
    if (q) {
      renderSearchResults(gamesNow, q);
      document.getElementById('categorySections').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      renderSections(gamesNow);
    }
  }

  document.addEventListener('pl:search', (e) => applyQuery(e.detail));

  const params = new URLSearchParams(window.location.search);
  const initialQuery = params.get('q') || '';
  if (initialQuery) {
    const input = document.querySelector('#siteSearchForm input');
    if (input) input.value = initialQuery;
  }

  /* ---------------- go ---------------- */

  initCarousel(allGames);
  applyQuery(initialQuery);
});
