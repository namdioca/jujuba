/* =========================================================
   PLAYLAND — login.js
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {
  const session = PL.getSession();
  if (session) {
    plToast('Você já está conectado como ' + session.username + '.');
  }

  const form = document.getElementById('loginForm');
  const idField = document.getElementById('loginId');
  const passField = document.getElementById('loginPass');

  function setInvalid(field, message) {
    const wrap = field.closest('.field');
    wrap.classList.add('invalid');
    wrap.querySelector('.field-error').textContent = message;
  }
  function clearInvalid(field) {
    field.closest('.field').classList.remove('invalid');
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let ok = true;
    clearInvalid(idField); clearInvalid(passField);

    if (!idField.value.trim()) { setInvalid(idField, 'Informe seu usuário ou email.'); ok = false; }
    if (!passField.value) { setInvalid(passField, 'Informe sua senha.'); ok = false; }
    if (!ok) return;

    const result = PL.login(idField.value, passField.value);
    if (!result.ok) {
      setInvalid(passField, 'Usuário ou senha incorretos.');
      plToast('Não foi possível entrar. Confira seus dados.', 'warn');
      return;
    }
    plToast('Bem-vindo(a) de volta, ' + result.user.username + '!', 'good');
    const next = new URLSearchParams(window.location.search).get('next') || 'index.html';
    setTimeout(() => window.location.href = next, 700);
  });

  document.getElementById('togglePass').addEventListener('click', () => {
    passField.type = passField.type === 'password' ? 'text' : 'password';
  });

  document.getElementById('forgotPass').addEventListener('click', () => {
    plToast('Recuperação de senha simulada: verifique seu email cadastrado. ✉️');
  });

  document.querySelectorAll('[data-social]').forEach(btn => {
    btn.addEventListener('click', () => {
      plToast('Login social indisponível nesta versão de demonstração.');
    });
  });
});
