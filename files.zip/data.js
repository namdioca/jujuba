/* =========================================================
   PLAYLAND — data.js
   Seed data + localStorage helpers shared by every page.
   No backend: "accounts" and "games" persist in the browser.
   ========================================================= */

const PL = (function () {

  const LS_KEYS = {
    users: 'pl_users',
    session: 'pl_session',
    games: 'pl_games',
    categories: 'pl_categories',
  };

  const CATEGORY_COLOR_CYCLE = ['#0300CF', '#B70F00', '#DE00FF', '#E6BF00', '#6E4CE0'];

  const DEFAULT_CATEGORIES = [
    { id: 'galera',   name: 'Jogos da galera',        color: '#0300CF', emoji: '🎉' },
    { id: 'acao',     name: 'Jogos de ação',          color: '#B70F00', emoji: '⚔️' },
    { id: 'cozinha',  name: 'Jogos de cozinhar',      color: '#DE00FF', emoji: '🍳' },
    { id: 'maquiar',  name: 'Jogos de maquiar',       color: '#E6BF00', emoji: '💄' },
    { id: 'puzzle',   name: 'Jogos de quebra-cabeças',color: '#6E4CE0', emoji: '🧩' },
  ];

  const DEFAULT_GAMES = [
    { id: 'g1',  nome: 'Corrida Arco-Íris',      categoria: 'galera',  emoji: '🌈', faixaEtaria: 'Livre', desenvolvedor: 'Estúdio Nuvem', descricao: 'Pilote carrinhos coloridos por pistas que mudam de forma a cada volta.', destaque: true },
    { id: 'g2',  nome: 'Fazenda Feliz',          categoria: 'galera',  emoji: '🐔', faixaEtaria: 'Livre', desenvolvedor: 'PixelBrejo', descricao: 'Cuide de animais, plante sementes e construa a fazenda dos seus sonhos.', destaque: false },
    { id: 'g3',  nome: 'Ilha Perdida',           categoria: 'galera',  emoji: '🏝️', faixaEtaria: '10+', desenvolvedor: 'Estúdio Nuvem', descricao: 'Explore uma ilha misteriosa em busca de tesouros escondidos.', destaque: false },
    { id: 'g4',  nome: 'Batalha de Bolhas',      categoria: 'galera',  emoji: '🫧', faixaEtaria: 'Livre', desenvolvedor: 'BolhaGames', descricao: 'Estoure bolhas em combos gigantes contra seus amigos.', destaque: false },

    { id: 'g5',  nome: 'Guerreiros do Vulcão',   categoria: 'acao',    emoji: '🌋', faixaEtaria: '12+', desenvolvedor: 'Estúdio Trovão', descricao: 'Enfrente exércitos de lava em batalhas épicas de arena.', destaque: true },
    { id: 'g6',  nome: 'Ninja Relâmpago',        categoria: 'acao',    emoji: '🥷', faixaEtaria: '10+', desenvolvedor: 'PixelBrejo', descricao: 'Corra pelos telhados e derrote inimigos com reflexos rápidos.', destaque: false },
    { id: 'g7',  nome: 'Zona de Impacto',        categoria: 'acao',    emoji: '💥', faixaEtaria: '14+', desenvolvedor: 'Estúdio Trovão', descricao: 'Pilote mechs em confrontos táticos de tirar o fôlego.', destaque: false },
    { id: 'g8',  nome: 'Caçador de Sombras',     categoria: 'acao',    emoji: '🗡️', faixaEtaria: '12+', desenvolvedor: 'NoiteViva', descricao: 'Persiga criaturas da noite por becos enevoados.', destaque: false },

    { id: 'g9',  nome: 'Doceria da Vovó',        categoria: 'cozinha', emoji: '🧁', faixaEtaria: 'Livre', desenvolvedor: 'Estúdio Nuvem', descricao: 'Monte receitas de doces clássicos antes que o forno apite.', destaque: true },
    { id: 'g10', nome: 'Chef Relâmpago',         categoria: 'cozinha', emoji: '👨‍🍳', faixaEtaria: 'Livre', desenvolvedor: 'PixelBrejo', descricao: 'Prepare pratos contra o tempo em uma cozinha frenética.', destaque: false },
    { id: 'g11', nome: 'Pizza Perfeita',         categoria: 'cozinha', emoji: '🍕', faixaEtaria: 'Livre', desenvolvedor: 'MassaGames', descricao: 'Combine ingredientes para agradar clientes exigentes.', destaque: false },
    { id: 'g12', nome: 'Sorveteria Mágica',      categoria: 'cozinha', emoji: '🍦', faixaEtaria: 'Livre', desenvolvedor: 'MassaGames', descricao: 'Crie sabores encantados em uma sorveteria que nunca dorme.', destaque: false },

    { id: 'g13', nome: 'Salão de Beleza',        categoria: 'maquiar', emoji: '💄', faixaEtaria: 'Livre', desenvolvedor: 'GlamStudio', descricao: 'Transforme visuais com maquiagens e penteados criativos.', destaque: true },
    { id: 'g14', nome: 'Princesa por um Dia',    categoria: 'maquiar', emoji: '👑', faixaEtaria: 'Livre', desenvolvedor: 'GlamStudio', descricao: 'Escolha looks reais para um baile inesquecível.', destaque: false },
    { id: 'g15', nome: 'Maquiagem Fashion',      categoria: 'maquiar', emoji: '💋', faixaEtaria: '10+', desenvolvedor: 'GlamStudio', descricao: 'Monte produções completas para desfiles virtuais.', destaque: false },
    { id: 'g16', nome: 'Estilista das Estrelas', categoria: 'maquiar', emoji: '✨', faixaEtaria: '10+', desenvolvedor: 'GlamStudio', descricao: 'Vista celebridades para o tapete vermelho.', destaque: false },

    { id: 'g17', nome: 'Blocos Encantados',      categoria: 'puzzle',  emoji: '🧩', faixaEtaria: 'Livre', desenvolvedor: 'MenteViva', descricao: 'Encaixe peças mágicas em quebra-cabeças que crescem em dificuldade.', destaque: true },
    { id: 'g18', nome: 'Labirinto Cósmico',      categoria: 'puzzle',  emoji: '🌌', faixaEtaria: '10+', desenvolvedor: 'MenteViva', descricao: 'Guie uma estrela por labirintos que giram no espaço.', destaque: false },
    { id: 'g19', nome: 'Engrenagens',            categoria: 'puzzle',  emoji: '⚙️', faixaEtaria: '12+', desenvolvedor: 'MenteViva', descricao: 'Monte mecanismos para resolver desafios de lógica.', destaque: false },
    { id: 'g20', nome: 'Torre Infinita',         categoria: 'puzzle',  emoji: '🗼', faixaEtaria: 'Livre', desenvolvedor: 'MenteViva', descricao: 'Empilhe blocos numéricos o mais alto que conseguir.', destaque: false },
  ];

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.warn('PLAYLAND: falha ao ler', key, e);
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('PLAYLAND: falha ao gravar', key, e);
      return false;
    }
  }

  function ensureSeed() {
    if (localStorage.getItem(LS_KEYS.categories) === null) {
      writeJSON(LS_KEYS.categories, DEFAULT_CATEGORIES);
    }
    if (localStorage.getItem(LS_KEYS.games) === null) {
      writeJSON(LS_KEYS.games, DEFAULT_GAMES);
    }
    if (localStorage.getItem(LS_KEYS.users) === null) {
      writeJSON(LS_KEYS.users, []);
    }
  }
  ensureSeed();

  function getCategories() { return readJSON(LS_KEYS.categories, DEFAULT_CATEGORIES); }
  function getGames() { return readJSON(LS_KEYS.games, DEFAULT_GAMES); }

  function addCategory(name) {
    const cats = getCategories();
    const exists = cats.some(c => c.name.trim().toLowerCase() === name.trim().toLowerCase());
    if (exists) return { ok: false, reason: 'duplicate' };
    const color = CATEGORY_COLOR_CYCLE[cats.length % CATEGORY_COLOR_CYCLE.length];
    const id = 'cat_' + Date.now().toString(36);
    const cat = { id, name: name.trim(), color, emoji: '🎮' };
    cats.push(cat);
    writeJSON(LS_KEYS.categories, cats);
    return { ok: true, category: cat };
  }

  function addGame(game) {
    const games = getGames();
    const id = 'g_' + Date.now().toString(36);
    const record = Object.assign({ id, destaque: false }, game);
    games.push(record);
    writeJSON(LS_KEYS.games, games);
    return record;
  }

  function categoryById(id) {
    return getCategories().find(c => c.id === id) || null;
  }

  /* ---------------- accounts (demo only, not secure) ---------------- */

  function getUsers() { return readJSON(LS_KEYS.users, []); }

  function findUser(identifier) {
    const id = identifier.trim().toLowerCase();
    return getUsers().find(u => u.username.toLowerCase() === id || u.email.toLowerCase() === id) || null;
  }

  function registerUser({ username, email, senha }) {
    const users = getUsers();
    const clash = users.some(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase());
    if (clash) return { ok: false, reason: 'duplicate' };
    const user = { username: username.trim(), email: email.trim(), senha };
    users.push(user);
    writeJSON(LS_KEYS.users, users);
    return { ok: true, user };
  }

  function login(identifier, senha) {
    const user = findUser(identifier);
    if (!user || user.senha !== senha) return { ok: false };
    setSession(user.username);
    return { ok: true, user };
  }

  function setSession(username) { writeJSON(LS_KEYS.session, { username }); }
  function getSession() { return readJSON(LS_KEYS.session, null); }
  function logout() { localStorage.removeItem(LS_KEYS.session); }

  return {
    keys: LS_KEYS,
    getCategories, getGames, addCategory, addGame, categoryById,
    getUsers, findUser, registerUser, login, getSession, setSession, logout,
  };
})();
